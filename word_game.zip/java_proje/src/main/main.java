/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;
import GUİ.main_gui;

/**
 *
 * @author kaank
 */
public class main {
        
    public static void main(String args[]){
        
       main_gui a = new main_gui();
       a.main_gui();
        
    }
    
}
